localhost:8081/call/save-students

header:
Content-Type:application/json

input data in post:
[{"firstName":"Pranoj","lastName":"Ashtamkar"},
{"firstName":"Anil","lastName":"Ejgar"},
{"firstName":"Yogesh","lastName":"Kshirsagar"},
{"firstName":"Ketan","lastName":"Patil"},
{"firstName":"Sanjay","lastName":"gawas"},
{"firstName":"ajay","lastName":"jadeja"},
{"firstName":"Sanjay","lastName":"khurana"}]


* create new database in mysql
  execution-service
  
* create new table student
  id, firstName, lastName