package com.example.callableservicedemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.callableservicedemo.form.Student;
import com.example.callableservicedemo.service.StudentService;


@RestController
@RequestMapping("/call")
public class MyCallableController {
	
	@Autowired
	StudentService studentService;

	@RequestMapping("/test-call")
	public ResponseEntity<String> testCall() {
		return new ResponseEntity<String>("{\"status\":\"success\"}", HttpStatus.OK);		
	}
	
	@PostMapping("save-students")
	public ResponseEntity<List<Student>> saveStudents(@RequestBody List<Student> studentList){
		
		List<Student> returnList = studentService.saveStudents(studentList);
		return new ResponseEntity<List<Student>>(returnList, HttpStatus.OK);
	}
}
