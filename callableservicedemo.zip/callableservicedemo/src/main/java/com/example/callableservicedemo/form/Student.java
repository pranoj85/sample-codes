package com.example.callableservicedemo.form;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "student")
public class Student {
	
	@Id
	@GeneratedValue
	public int id;
	public String firstName;
	public String lastName;
	
	@Override
	public String toString() {
		return "" + this.id + " " + this.firstName + " " + this.lastName;
	}
	
}
