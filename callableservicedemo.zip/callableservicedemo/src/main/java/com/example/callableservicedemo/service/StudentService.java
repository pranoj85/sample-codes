package com.example.callableservicedemo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.callableservicedemo.form.Student;
import com.example.callableservicedemo.repo.StudentRepository;

@Service
public class StudentService{
	
	@Autowired
	StudentRepository studentRepository;
	
	public List<Student> saveStudents(List<Student> students) {
		
		List<Future<Student>> futures = new ArrayList<Future<Student>>();
		List<Student> saveStudentList = new ArrayList<Student>(); 
		ExecutorService exService = Executors.newFixedThreadPool(3);
		
		for(Student student : students) {
			Future<Student> feture = exService.submit(new StudentSaveService(student, this.studentRepository));
			futures.add(feture);
		}
		
		for (int i=0;i<futures.size();i++) {
			try {
				saveStudentList.add(futures.get(i).get());
			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (ExecutionException e) {
				e.printStackTrace();
			}
		}
		
		return saveStudentList;
	}

}

class StudentSaveService implements Callable<Student> {
	
	private Student student = null;
	
	StudentRepository studentRepository;
	
	public StudentSaveService() {}
	
	public StudentSaveService(Student student, StudentRepository studentRepository) {
		this.student = student;
		this.studentRepository = studentRepository;
	}
	
	@Override
	public Student call() throws Exception {
		try {
			this.student = this.studentRepository.save(this.student); 
			System.out.println(this.student.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return this.student;
	}
}


