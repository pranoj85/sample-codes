package com.example.callableservicedemo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.callableservicedemo.form.Student;

public interface StudentRepository extends JpaRepository<Student, Integer>{

}
