package com.example.callableservicedemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CallableservicedemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CallableservicedemoApplication.class, args);
	}

}
