
public class Fiboniccie {

	public static void main(String[] args) {
		// fibonice
	      
	      int num = 0;
	      int fibonum = 0;
	      int currentNum = 1;
	      int previousNum = 0;
	      
	      System.out.println(fibonum);
	      
	      while (num < 10){
	          
	          
	          
	          fibonum = previousNum + currentNum;
	          System.out.println(fibonum);
	          currentNum = previousNum;
	          previousNum =  fibonum;
	          
	          num++;
	      }

	}

}
