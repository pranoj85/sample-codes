import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Predicate;

public class BiConsumerDemo {

	public static void main(String[] args) {

		List<Emp> empList = new ArrayList<>();
		empList.add(new Emp("Sagar", 250000));
		empList.add(new Emp("Ajit", 220000));
		empList.add(new Emp("Amol", 200000));
		empList.add(new Emp("Deven", 240000));
		empList.add(new Emp("Rahul", 210000));

		
		BiConsumer<Emp, Emp> bEmp = (a, b) -> {
			if (b.name.startsWith("D") && a.salary > 21000) {
				System.out.println(a.name);
			}
		};
		
		bEmp.accept(new Emp("Sagar", 250000), new Emp("Deven", 240000));
		
		
		Predicate<List<Emp>> listPred = (emp1) -> {
			System.out.println(emp1.get(0));
			return true;
		};
		
	}

}
