import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ExecutorServiceCallable {

	public static void main(String[] args) {
		
		String [] jobs =  {"Batch job", "Paid job", "Job1", "Job2"};
		List<Future<String>> futures = new ArrayList<Future<String>>();
		ExecutorService exService = Executors.newFixedThreadPool(3);
		
		for (int i=0;i<jobs.length;i++) {
			Future<String> feture = exService.submit(new Dojob(jobs[i]));
			futures.add(feture);
		}
		
		for (int i=0;i<jobs.length;i++) {
			System.out.println(futures.get(i));
		}
	}
}


class Dojob implements Callable<String> {
	
	String Name;
	
	public Dojob(String name) {
		this.Name = name;
	}

	@Override
	public String call() throws Exception {
		String result = null;
		switch (this.Name) {
		case "Batch job":
			result = "Batch Job Finished Successfully";
			break;
		case "Paid job":
			result = "Paid Job Finished Successfully";
			break;	
			
		default:
			result = "Unknown job:"+this.Name;
			break;
		}
		
		return result;
	}
	
}



