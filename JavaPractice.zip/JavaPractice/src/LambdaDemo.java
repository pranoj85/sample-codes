
public class LambdaDemo {

	public static void main(String[] args) {
		Definable def = (int s) -> {
			System.out.println("I am defining event "+ s);
			System.out.println("*"+ s);
		};
		 
		def.move(5);

	}

}

interface Definable {
	void move(int s);
}