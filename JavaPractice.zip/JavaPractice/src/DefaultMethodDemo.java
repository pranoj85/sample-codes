
public class DefaultMethodDemo {

	public static void main(String[] args) {
		Car c1 = new Car();
		c1.start();
		c1.run();
	}

}

@FunctionalInterface
interface Vehical {

	public void start();
	
	default void run() {
		System.out.println("I am running ...");
	}
}


class Car implements Vehical {
	public void run() {
		System.out.println("I am running car");
	}

	@Override
	public void start() {
		System.out.println("car started");
		
	}
}