import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @author 047945
 *
 */
public class StreamDemo2 {

	public static void main(String[] args) {

		String[] students = {"A,11,20", "B,15,17", "C,12,14", "D,19,20", "E,16,13"};
		
		Map<String, Integer>  topInHistory = new HashMap<>();
		
		topInHistory = Arrays.asList(students)
				.stream()
				.map(x -> x.split(","))
				.filter(x -> Integer.parseInt(x[1]) > 12)
				.collect(Collectors.toMap(x -> x[0], x-> Integer.parseInt(x[1])));
		
		System.out.println("Top Student in Maths out of 20");
		System.out.println(topInHistory);
		
		
		
		Integer sum = Arrays.asList(students).stream().map(x->x.split(",")).map(x->Integer.parseInt(x[1])).reduce(Integer::sum).get();
		System.out.println("Sum of maths marks of all students:" +sum);

 
// @formatter:on

		
		

	}

}
