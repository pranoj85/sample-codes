import java.util.ArrayList;
import java.util.List;

public class StreamDemo1 {

	public static void main(String[] args) {
		List<Emp> empList = new ArrayList<>();
		empList.add(new Emp("Sagar", 250000));
		empList.add(new Emp("Ajit", 220000));
		empList.add(new Emp("Amol", 200000));
		empList.add(new Emp("Deven", 240000));
		empList.add(new Emp("Rahul", 210000));

		System.out.println("-------------");
		System.out.println("ASC Order");
		System.out.println("-------------");
		empList.stream().sorted((e1, e2) -> e1.salary.compareTo(e2.salary)).forEach(System.out::println);

		System.out.println("-------------");
		System.out.println("DESC Order");
		System.out.println("-------------");
		empList.stream().sorted((e1, e2) -> e2.salary.compareTo(e1.salary)).forEach(System.out::println);

		Emp secondHighest = empList.stream().sorted((e1, e2) -> e2.salary.compareTo(e1.salary)).skip(1).findFirst()
				.get();

		System.out.println("-------------");
		System.out.println("Second Highest Salary employee");
		System.out.println("-------------");
		System.out.println(secondHighest);

		Emp secondLowest = empList.stream().sorted((e1, e2) -> e1.salary.compareTo(e2.salary)).skip(1).findFirst()
				.get();

		System.out.println("-------------");
		System.out.println("Second Lowest Salary employee");
		System.out.println("-------------");
		System.out.println(secondLowest);
		
		
		int i = 10;
		boolean b = (i++>10)&&(++i<15);
		System.out.println(i);
		
	}

}

class Emp {

	String name;
	Integer salary;

	public Emp(String nm, Integer sal) {
		this.name = nm;
		this.salary = sal;
	}

	@Override
	public String toString() {
		return this.name + " " + this.salary;
	}

}
