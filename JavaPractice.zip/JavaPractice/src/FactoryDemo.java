import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

abstract class Person {
	public abstract String getRole();
}

class Employee extends Person {
	public String getRole() {
		return "I am Employee at office.";
	}
}

class Father extends Person {
	public String getRole() {
		return "I am Father at home";
	}
}

class PersonFactory {
	public Person getPerson(String personType) {

		if (personType == null) {
			return null;
		}

		if (personType.equalsIgnoreCase("EMPLOYEE")) {
			return new Employee();
		} else if (personType.equalsIgnoreCase("FATHER")) {
			return new Father();
		}

		return null;
	}
}

public class FactoryDemo {

	public static void main(String[] args) {
		
		String personType = null;
		System.out.println("Enter ther person type (employee/father):");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		try {
			personType = br.readLine();
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Unable to read person type.");
		}
		
		if (personType != null) {
			PersonFactory pfactory = new PersonFactory();
			Person person  = pfactory.getPerson(personType);
			System.out.println(person.getRole());
		}
	}
}
