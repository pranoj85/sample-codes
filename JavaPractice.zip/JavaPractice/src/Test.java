
class Foo {
	final static int x = 30;
	static {
		System.out.println("static block");
	}
}

public class Test {

	
	public static void main(String[] args) {
		int a = 10;
		int b = 9;
		int c = 7;
				
	    a = a>>b ^ c<<2;
	    System.out.println(a);
		
	}
}
