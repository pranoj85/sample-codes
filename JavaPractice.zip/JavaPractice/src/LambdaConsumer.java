import java.util.function.BiConsumer;

public class LambdaConsumer {

	public static void main(String[] args) {
		 int[] value = {0, 1, 2, 3, 4};
		 int key = 1;
		 addLambda(value, key, (v, k) -> System.out.println(v + key));
	}
	
	private static void addLambda(int[] values, int key, BiConsumer<Integer, Integer> bConsumer) {
		for(int i: values) {
			bConsumer.accept(i, key);
		}
	}

}
