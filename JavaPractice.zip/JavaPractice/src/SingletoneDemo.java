
public class SingletoneDemo {

	private static SingletoneDemo singletone;
	
	
	public static SingletoneDemo getInstance( ) {
		if (singletone == null) {
			singletone = new SingletoneDemo();
		}
		
		return singletone;
	}
	
	public void print( ) {
		System.out.println("I am singletone instance only.");
	}
	
	
	public static void main(String[] args) {
		SingletoneDemo singletoneDemo = SingletoneDemo.getInstance();
		singletoneDemo.print();
	}
	
}
